package id.infinitelearning.KotlinSubmission.exercise1



internal class AppKtTest {


}