package id.infinitelearning.KotlinSubmission.exercise1

/**
Latihan 1
Lengkapi fungsi myProfile di bawah ini dengan membuat variabel dengan ketentuan dibawah ini:
- Variable bertipe data string yang menyimpan nilai nama depan Anda.
- Variable bertipe data string yang menyimpan nilai nama belakang Anda.
- Variable bertipe data number yang menyimpan nilai umur Anda.
- Variable bertipe data boolean yang menyimpan nilai status Anda (single atau tidak)
- Dan cetak setiap variabel ke layar saat fungsi myProfile() di panggil
 */
fun myProfile() {
    val firstName: String = "Devita"
    val lastName: String = "Krisnawati"
    val age: Int = 22
    val isSingle: Boolean = false

    println("Nama saya: $firstName $lastName")
    println("Umur saya: $age tahun")
    if (isSingle) {
        println("Status: Single")
    } else {
        println("Status: Tidak Single")
    }
}




/**
 *  Latihan 2
 *  Lengkapi fungsi di bawah ini agar dapat mencetak nilai dari parameter-parameter yang ada dengan fungsi println
 */
fun groupDetail(groupId: Int, groupMember: List<Any>, session: String): Any {
    println("ID Grup: $groupId")
    println("Anggota Grup: $groupMember")
    println("Sesi: $session")

    return arrayOf(groupId, groupMember, session)
}

/**
 * Latihan 3
 * Buat variable yang berisi daftar anggota group kamu,
 * Kemudian akses item yang berisi nama Anda dari variable tersebut, lalu jadikan nilai kembalian untuk fungsi myGroup ini
 *
 */
fun myGroup(): String {
    val groupMembers = listOf("Haikal", "Devita", "Ahmad", "Angel", "Nisyah", "Naufal", "Tri", "Tsania", "Apriman")

    val myName = groupMembers[1]

    return myName
}

/**
 * Latihan 4
 * Ubah nilai kembalian untuk fungsi totalMember ini dengan rumus:
 *
 *      total mentor + jumlah anggota group
 *
 */
fun totalMember(totalMentor: Int, totalAnggota: Int): Int {
    val jumlahTotalMember = totalMentor + totalAnggota
    return jumlahTotalMember

}
fun main() {

    myProfile()

    val groupId = 5
    val groupMember = listOf("Haikal", "Devita", "Ahmad", "Angel", "Nisyah", "Naufal", "Tri", "Tsania", "Apriman")
    val session = "Sesi Siang"

    groupDetail(groupId, groupMember, session)

    val myGroupName = myGroup()
    println("Nama saya dalam grup: $myGroupName")

    val mentorCount = 2
    val anggotaCount = 9

    val total = totalMember(mentorCount, anggotaCount)
    println("Jumlah total anggota grup: $total")

    /**
     *  Latihan 5
     *  Ubah nilai argumen-argumen dari fungsi groupDetail di bawah ini sesuai dengan data group kamu
     *
     */
    groupDetail(5, listOf("Haikal", "Devita", "Ahmad", "Angel", "Nisyah", "Naufal", "Tri", "Tsania", "Apriman"), "Afternoon")


}