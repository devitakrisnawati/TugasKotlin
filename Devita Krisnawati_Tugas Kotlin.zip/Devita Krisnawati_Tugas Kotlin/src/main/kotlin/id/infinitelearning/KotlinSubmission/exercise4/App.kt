package id.infinitelearning.KotlinSubmission.exercise4

fun main() {

    /**
     * Buatlah contoh code penggunaan try catch untuk menangani suatu kasus sesuai keinginan teman-teman
     *
     */
        val numberStr = "123"
        val nonNumericStr = "abc"

        try {
            val number = numberStr.toInt()
            println("Konversi ke Integer berhasil: $number")
        } catch (e: NumberFormatException) {
            println("Terjadi kesalahan konversi: ${e.message}")
        }

        try {
            val nonNumericNumber = nonNumericStr.toInt()
            println("Konversi ke Integer berhasil: $nonNumericNumber")
        } catch (e: NumberFormatException) {
            println("Terjadi kesalahan konversi: ${e.message}")
        }
    }